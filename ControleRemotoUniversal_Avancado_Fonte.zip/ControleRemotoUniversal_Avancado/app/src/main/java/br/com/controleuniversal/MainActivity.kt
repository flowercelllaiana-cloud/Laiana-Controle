package br.com.controleuniversal

import android.app.Activity
import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject

class MainActivity : Activity() {
    private var ir: ConsumerIrManager? = null
    private lateinit var status: TextView
    private lateinit var mode: Spinner
    private lateinit var brand: Spinner
    private lateinit var ipInput: EditText

    // Códigos NEC ilustrativos. Não são uma base universal nem códigos validados por marca.
    private val demoNec = mapOf(
        "Power" to 0x00, "Volume +" to 0x02, "Volume -" to 0x03,
        "Mute" to 0x04, "Canal +" to 0x06, "Canal -" to 0x07,
        "OK" to 0x08, "Voltar" to 0x09, "Menu" to 0x0A, "Home" to 0x0B,
        "Cima" to 0x0C, "Baixo" to 0x0D, "Esquerda" to 0x0E, "Direita" to 0x0F
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ir = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(0xFF10151F.toInt())
        }
        fun label(text: String, size: Float = 15f) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(0xFFF2F5FA.toInt())
            setPadding(0, 8, 0, 8)
        }
        root.addView(label("CONTROLE REMOTO", 23f))
        root.addView(label("Infravermelho + Smart TV por rede", 14f))

        root.addView(label("Modo de conexão"))
        mode = Spinner(this)
        mode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Infravermelho (IR)", "Wi-Fi (compatibilidade por fabricante)"))
        root.addView(mode, matchWrap())

        root.addView(label("Marca da TV"))
        brand = Spinner(this)
        brand.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Selecione a marca", "Samsung", "LG webOS", "TCL", "Philips", "Philco", "AOC", "Android TV / Google TV", "Outra"))
        root.addView(brand, matchWrap())

        root.addView(label("IP da TV (para integrações Wi-Fi compatíveis)"))
        ipInput = EditText(this).apply {
            hint = "Ex.: 192.168.1.50"
            setSingleLine(true)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AA7BA.toInt())
            setPadding(12, 8, 12, 8)
        }
        root.addView(ipInput, matchWrap())

        val connect = Button(this).apply {
            text = "Verificar modo selecionado"
            setOnClickListener { checkMode() }
        }
        root.addView(connect, matchWrap())

        status = label("", 13f)
        root.addView(status, matchWrap())
        refreshStatus()

        root.addView(label("Comandos", 18f))
        addButtonRow(root, listOf("Power"))
        addButtonRow(root, listOf("Voltar", "Home", "Menu"))
        addButtonRow(root, listOf("Cima", "OK", "Baixo"))
        addButtonRow(root, listOf("Esquerda", "OK", "Direita"))
        addButtonRow(root, listOf("Canal -", "Mute", "Canal +"))
        addButtonRow(root, listOf("Volume -", "Volume +"))

        root.addView(label("Teclado numérico", 18f))
        addButtonRow(root, listOf("1", "2", "3"))
        addButtonRow(root, listOf("4", "5", "6"))
        addButtonRow(root, listOf("7", "8", "9"))
        addButtonRow(root, listOf("*", "0", "#"))

        root.addView(label(
            "Limitações: os códigos IR são de demonstração. Wi-Fi depende do sistema, do modelo e do pareamento da TV; selecionar uma marca não garante compatibilidade. Esta versão ainda não implementa controladores Wi-Fi específicos para todas as marcas.",
            12f
        ))
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun addButtonRow(root: LinearLayout, labels: List<String>) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        labels.forEach { text ->
            val button = Button(this).apply {
                this.text = text
                isAllCaps = false
                setOnClickListener { sendCommand(text) }
            }
            row.addView(button, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(row, matchWrap())
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun refreshStatus() {
        val hasIr = ir?.hasIrEmitter() == true
        status.text = if (hasIr) {
            "Emissor infravermelho detectado. Os comandos só funcionarão se o protocolo/código corresponder à TV."
        } else {
            "Este celular não informa emissor infravermelho. Use um método Wi-Fi compatível com a sua TV."
        }
    }

    private fun checkMode() {
        if (mode.selectedItemPosition == 0) {
            refreshStatus()
            Toast.makeText(this, if (ir?.hasIrEmitter() == true) "IR disponível no aparelho" else "Sem emissor IR detectado", Toast.LENGTH_LONG).show()
        } else {
            val ip = ipInput.text.toString().trim()
            if (ip.isBlank()) {
                status.text = "Informe o IP da TV e confirme que celular e televisão estão na mesma rede Wi-Fi."
            } else {
                status.text = "IP informado: $ip. Esta compilação não envia comandos Wi-Fi universais; é necessária a integração correspondente ao sistema/modelo."
            }
        }
    }

    private fun sendCommand(command: String) {
        if (mode.selectedItemPosition != 0) {
            Toast.makeText(this, "O comando Wi-Fi ainda precisa da integração específica da TV selecionada.", Toast.LENGTH_LONG).show()
            return
        }
        val manager = ir
        if (manager == null || !manager.hasIrEmitter()) {
            Toast.makeText(this, "Este celular não tem emissor IR. Troque para uma integração Wi-Fi compatível.", Toast.LENGTH_LONG).show()
            return
        }
        val code = demoNec[command]
        if (code == null) {
            if (command.length == 1 && command[0].isDigit()) {
                Toast.makeText(this, "Tecla numérica ainda não possui código IR cadastrado.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Comando sem código IR de demonstração.", Toast.LENGTH_SHORT).show()
            }
            return
        }
        val address = 0x00
        val commandByte = code and 0xFF
        val pattern = mutableListOf<Int>()
        pattern += 9000; pattern += 4500
        fun appendByte(value: Int) {
            for (i in 0..7) {
                pattern += 560
                pattern += if (((value shr i) and 1) == 1) 1690 else 560
            }
        }
        appendByte(address)
        appendByte(address.inv() and 0xFF)
        appendByte(commandByte)
        appendByte(commandByte.inv() and 0xFF)
        pattern += 560
        pattern += 40000
        try {
            manager.transmit(38000, pattern.toIntArray())
            Toast.makeText(this, "Quadro IR de demonstração enviado: $command", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Erro ao transmitir IR: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
