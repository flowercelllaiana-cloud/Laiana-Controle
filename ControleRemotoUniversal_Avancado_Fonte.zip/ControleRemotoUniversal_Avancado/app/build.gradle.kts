plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "br.com.controleuniversal"
    compileSdk = 35
    defaultConfig {
        applicationId = "br.com.controleuniversal"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
