# Controle Remoto Universal Avançado — Android

## Estado real desta entrega
Este é um projeto Android de interface avançada, com seleção de marca/modo, botões de navegação, volume, canais e teclado numérico, além da detecção do emissor IR. **Não é ainda um controle universal funcional para todas as TVs e não inclui um APK compilado.** O ambiente desta entrega não tem Android SDK/Gradle configurado para gerar e testar o APK.

## Limitações importantes
- **IR:** `ConsumerIrManager` só transmite se o aparelho tiver emissor IR. Os códigos NEC presentes são exemplos ilustrativos e não são códigos verificados para Samsung, LG, TCL, Philips, Philco, AOC ou outras marcas.
- **Wi-Fi:** não existe um protocolo universal para todas as Smart TVs. Cada plataforma pode exigir descoberta, autorização/pareamento, protocolo local ou API do fabricante.
- A tela Wi-Fi nesta versão é uma base de interface e validação de IP; ainda não envia comandos de rede. Não trate a escolha da marca como garantia de compatibilidade.
- Para implementar de verdade, é necessário definir e testar os modelos-alvo. LG webOS, Samsung Tizen/SmartThings, Android TV/Google TV e outros sistemas têm fluxos diferentes.

## Gerar APK no Android Studio
1. Instale Android Studio e um JDK compatível (JDK 17 recomendado).
2. Abra esta pasta no Android Studio.
3. Instale o Android SDK 35 no SDK Manager, se solicitado.
4. Aguarde a sincronização do Gradle.
5. Escolha **Build > Build APK(s)**.
6. O APK de depuração normalmente estará em `app/build/outputs/apk/debug/app-debug.apk`.

## Próxima etapa técnica recomendada
Escolher primeiro 1 ou 2 plataformas reais e modelos para testar, implementar cada driver em módulo separado e validar pareamento e comandos em TVs físicas. Só depois ampliar a matriz de compatibilidade e publicar o APK.
